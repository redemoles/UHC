
#> bhc:test/scoreboard/
#
#
#
#
# @description		
#

tellraw @a[tag=uhc.host] [{"score":{"name":"","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§0§1","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§0§2","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§0§3","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§0§4","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§0§5","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§0§6","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§0§7","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§0§8","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§0§9","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§1§0","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§1§1","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§1§2","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§1§3","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§1§4","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§1§5","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§1§6","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§1§7","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§1§8","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§1§9","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§2§0","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§2§1","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§2§2","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§2§3","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§2§4","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§2§5","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§2§6","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§2§7","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§2§8","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§2§9","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§3§0","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§3§1","objective":"bhc.stepa.rank.score"}}]
tellraw @a[tag=uhc.host] [{"score":{"name":"§r§3§2","objective":"bhc.stepa.rank.score"}}]
