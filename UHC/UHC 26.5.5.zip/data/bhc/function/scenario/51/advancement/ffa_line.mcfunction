
#> bhc:scenario/51/advancement/ffa_line
#
# @within			bhc:scenario/51/advancement/new_adv
#
#
# @description		Don du dernier succès non complété d'une ligne si FFA
#

$advancement grant @s only $(namespace):$(line)_1
$advancement grant @s only $(namespace):$(line)_2
$advancement grant @s only $(namespace):$(line)_3
$advancement grant @s only $(namespace):$(line)_4
$advancement grant @s only $(namespace):$(line)_5
$advancement grant @s only $(namespace):$(line)_6
$advancement grant @s only $(namespace):$(line)_7
$advancement grant @s only $(namespace):$(line)_8
$advancement grant @s only $(namespace):$(line)_9
