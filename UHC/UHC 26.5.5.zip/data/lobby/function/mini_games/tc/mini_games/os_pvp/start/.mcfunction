
#> lobby:mini_games/tc/mini_games/os_pvp/start/
#
# @within			lobby:mini_games/tc/timer/start/
#
#
# @description		Démarrage du mini-jeu One Shot PvP
#

# Timer pre-start
execute if score #timer_start_tick lobby.tc.data matches 300 run scoreboard players set #timer_start_tick lobby.tc.data 120

execute if score #timer_start_tick lobby.tc.data matches 120 as @a[tag=mgs.tc.player] run tp @s ~ ~5 ~-21 0 0



execute if score #timer_start_tick lobby.tc.data matches 120 as @a[tag=mgs.tc.player] run title @s title [{"text":"One Shot PvP","color":"#FFE73F"}]
execute if score #timer_start_tick lobby.tc.data matches 120 as @a[tag=mgs.tc.player] run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 2 0.5

execute if score #timer_start_tick lobby.tc.data matches 90 as @a[tag=mgs.tc.player] run title @s title [{"text":"One Shot PvP","color":"#FFE73F"}]
execute if score #timer_start_tick lobby.tc.data matches 90 run function uhc:translation/lobby/tc_4m_start
execute if score #timer_start_tick lobby.tc.data matches 90 as @a[tag=mgs.tc.player] run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.5 2 0.5

execute if score #timer_start_tick lobby.tc.data matches 00 run scoreboard players set #timer_game_min lobby.tc.data 2
execute if score #timer_start_tick lobby.tc.data matches 00 run scoreboard players set #timer_game_sec lobby.tc.data 40
execute if score #timer_start_tick lobby.tc.data matches 00 run scoreboard players set #timer_game lobby.tc.data 160

execute if score #timer_start_tick lobby.tc.data matches 00 as @a[tag=mgs.tc.player,tag=!mgs.tc.spec] run attribute @s minecraft:attack_damage modifier remove uhc.lobby
execute if score #timer_start_tick lobby.tc.data matches 00 in uhc:lobby run gamerule minecraft:pvp true
