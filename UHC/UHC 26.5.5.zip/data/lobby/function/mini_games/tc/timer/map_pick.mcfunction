
#> lobby:mini_games/tc/timer/map_pick
#
# @within			lobby:mini_games/tc/tick
#
#
# @description		Tirage du mini-jeu
#

# Reset ancien mini-jeu
scoreboard players set #playing_craft lobby.tc.data 0
scoreboard players set #playing_ctb lobby.tc.data 0
scoreboard players set #playing_memory_build lobby.tc.data 0
scoreboard players set #playing_os_pve lobby.tc.data 0
scoreboard players set #playing_os_pvp lobby.tc.data 0
scoreboard players set #playing_parkour lobby.tc.data 0
scoreboard players set #playing_puzzle lobby.tc.data 0

# Changement de mini-jeu
scoreboard players add #random_mini_games_pick lobby.tc.data 1
execute unless entity @n[type=minecraft:marker,distance=0..,predicate=lobby:tc/id_mini_games] run scoreboard players set #random_mini_games_pick lobby.tc.data 1
fill -22 ~1 -22 22 ~9 22 minecraft:air








# Mise en place du mini-jeu
execute unless score #timer_start_tick lobby.tc.data matches 1.. as @n[type=minecraft:marker,distance=0..,predicate=lobby:tc/id_mini_games,tag=lobby.tc.craft] run function lobby:mini_games/tc/timer/map_pick
execute unless score #timer_start_tick lobby.tc.data matches 1.. as @n[type=minecraft:marker,distance=0..,predicate=lobby:tc/id_mini_games,tag=lobby.tc.ctb] run function lobby:mini_games/tc/mini_games/ctb/main
execute unless score #timer_start_tick lobby.tc.data matches 1.. as @n[type=minecraft:marker,distance=0..,predicate=lobby:tc/id_mini_games,tag=lobby.tc.memory_build] run function lobby:mini_games/tc/mini_games/memory_build/main
execute unless score #timer_start_tick lobby.tc.data matches 1.. as @n[type=minecraft:marker,distance=0..,predicate=lobby:tc/id_mini_games,tag=lobby.tc.os_pve] run function lobby:mini_games/tc/mini_games/os_pve/main
execute unless score #timer_start_tick lobby.tc.data matches 1.. as @n[type=minecraft:marker,distance=0..,predicate=lobby:tc/id_mini_games,tag=lobby.tc.os_pvp] run function lobby:mini_games/tc/timer/map_pick
execute unless score #timer_start_tick lobby.tc.data matches 1.. as @n[type=minecraft:marker,distance=0..,predicate=lobby:tc/id_mini_games,tag=lobby.tc.parkour] run function lobby:mini_games/tc/mini_games/parkour/main
execute unless score #timer_start_tick lobby.tc.data matches 1.. as @n[type=minecraft:marker,distance=0..,predicate=lobby:tc/id_mini_games,tag=lobby.tc.puzzle] run function lobby:mini_games/tc/timer/map_pick

stopsound @a[tag=mgs.tc.player]
