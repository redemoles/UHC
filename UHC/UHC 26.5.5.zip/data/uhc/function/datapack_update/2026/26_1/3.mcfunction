
#> uhc:datapack_update/2026/26_1/3
#
# @within			uhc:datapack_update/list
#
#
# @description		Mise à jour du datapack - UHC 26.1.3
#

scoreboard objectives add bhc.targeted.former_id dummy
scoreboard objectives add bhc.targeter.former_id dummy

execute if score #game_progress uhc.game_progress matches 1.. run return run scoreboard players set #warning uhc.data.update 2

scoreboard players set #update uhc.data.update 26013
