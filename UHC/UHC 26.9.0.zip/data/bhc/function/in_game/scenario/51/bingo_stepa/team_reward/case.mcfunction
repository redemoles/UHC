
#> bhc:in_game/scenario/51/bingo_stepa/team_reward/case
#
# @within			bhc:in_game/scenario/51/advancement/new_adv_1
#
#
# @description		Ajout de points
#

# Ajout de points au joueur et à l'équipe
scoreboard players operation @s bhc.stepa.score.inv /= #1m uhc.data.numbers
scoreboard players add @s bhc.stepa.score.inv 1
$execute if score #team_first_line_$(line) bhc.data matches 1 run scoreboard players add @s bhc.stepa.score.inv 2
$execute if score #team_first_column_$(column) bhc.data matches 1 run scoreboard players add @s bhc.stepa.score.inv 2
scoreboard players operation @a[predicate=uhc:id/team] bhc.stepa.score.inv = @s bhc.stepa.score.inv
scoreboard players operation @s bhc.stepa.score.inv *= #1m uhc.data.numbers
scoreboard players add @e[type=minecraft:marker,tag=UHC,distance=0..] bhc.stepa.score.inv 1
scoreboard players add @s bhc.stepa.case 1

# Son
execute as @a[predicate=uhc:id/team] at @s run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.5 1 0.5

# Classement
execute as @e[type=minecraft:marker,tag=UHC,distance=0..] run function bhc:in_game/scores_calculator/stepa/rank
execute as @e[type=minecraft:marker,tag=UHC,distance=0..] run function bhc:in_game/scores_calculator/bingos/rank
