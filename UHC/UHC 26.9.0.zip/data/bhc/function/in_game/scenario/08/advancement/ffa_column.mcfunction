
#> bhc:in_game/scenario/08/advancement/ffa_column
#
# @within			bhc:in_game/scenario/08/advancement/new_adv
#
#
# @description		Don du dernier succès non complété d'une colonne si FFA
#

$advancement grant @s only $(namespace):1_$(column)
$advancement grant @s only $(namespace):2_$(column)
$advancement grant @s only $(namespace):3_$(column)
$advancement grant @s only $(namespace):4_$(column)
$advancement grant @s only $(namespace):5_$(column)
$advancement grant @s only $(namespace):6_$(column)
$advancement grant @s only $(namespace):7_$(column)
$advancement grant @s only $(namespace):8_$(column)
$advancement grant @s only $(namespace):9_$(column)
