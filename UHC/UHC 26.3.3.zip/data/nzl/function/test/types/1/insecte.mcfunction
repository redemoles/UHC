
#> nzl:test/types/1/insecte
#
# @within			nzl:tick
#
#
# @description		Test d'évolution du type
#


scoreboard players set @s nzl.type.select 09
function nzl:types/evolve/1/disponible/insecte
