
execute if score #bingo_91a_enabled bhc.data matches 1 run data modify storage bingo_91a 4_3 set value {title:"Mud Brick Stairs", description:"Obtenir un(e) Mud Brick Stairs", namespace:"bingo_91a", step:"1", line:"4", column:"3"}
execute if score #bingo_91a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91a 4_3
execute unless score #bingo_91a_enabled bhc.data matches 1 run advancement revoke @s only bingo_91a:4_3
