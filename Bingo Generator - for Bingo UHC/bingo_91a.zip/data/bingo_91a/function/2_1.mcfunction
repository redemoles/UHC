
execute if score #bingo_91a_enabled bhc.data matches 1 run data modify storage bingo_91a 2_1 set value {title:"Copper Axe", description:"Obtenir un(e) Copper Axe", namespace:"bingo_91a", step:"1", line:"2", column:"1"}
execute if score #bingo_91a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91a 2_1
execute unless score #bingo_91a_enabled bhc.data matches 1 run advancement revoke @s only bingo_91a:2_1
