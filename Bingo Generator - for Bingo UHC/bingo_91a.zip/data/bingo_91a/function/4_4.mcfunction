
execute if score #bingo_91a_enabled bhc.data matches 1 run data modify storage bingo_91a 4_4 set value {title:"Golden Boots", description:"Obtenir un(e) Golden Boots", namespace:"bingo_91a", step:"1", line:"4", column:"4"}
execute if score #bingo_91a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91a 4_4
execute unless score #bingo_91a_enabled bhc.data matches 1 run advancement revoke @s only bingo_91a:4_4
