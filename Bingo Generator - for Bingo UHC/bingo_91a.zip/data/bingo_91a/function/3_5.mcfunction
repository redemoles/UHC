
execute if score #bingo_91a_enabled bhc.data matches 1 run data modify storage bingo_91a 3_5 set value {title:"Glowstone Dust", description:"Obtenir un(e) Glowstone Dust", namespace:"bingo_91a", step:"1", line:"3", column:"5"}
execute if score #bingo_91a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91a 3_5
execute unless score #bingo_91a_enabled bhc.data matches 1 run advancement revoke @s only bingo_91a:3_5
