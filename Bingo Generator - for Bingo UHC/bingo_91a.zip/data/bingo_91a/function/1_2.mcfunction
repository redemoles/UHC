
execute if score #bingo_91a_enabled bhc.data matches 1 run data modify storage bingo_91a 1_2 set value {title:"Light Blue Banner", description:"Obtenir un(e) Light Blue Banner", namespace:"bingo_91a", step:"1", line:"1", column:"2"}
execute if score #bingo_91a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91a 1_2
execute unless score #bingo_91a_enabled bhc.data matches 1 run advancement revoke @s only bingo_91a:1_2
