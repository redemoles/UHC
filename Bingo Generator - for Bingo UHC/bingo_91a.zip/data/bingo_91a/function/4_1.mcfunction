
execute if score #bingo_91a_enabled bhc.data matches 1 run data modify storage bingo_91a 4_1 set value {title:"Stone Slab", description:"Obtenir un(e) Stone Slab", namespace:"bingo_91a", step:"1", line:"4", column:"1"}
execute if score #bingo_91a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91a 4_1
execute unless score #bingo_91a_enabled bhc.data matches 1 run advancement revoke @s only bingo_91a:4_1
