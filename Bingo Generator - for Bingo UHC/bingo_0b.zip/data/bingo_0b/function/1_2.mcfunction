
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 1_2 set value {title:"Spyglass", description:"Obtenir un(e) Spyglass", namespace:"bingo_0b", step:"2", line:"1", column:"2"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 1_2
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:1_2
