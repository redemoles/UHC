
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 4_4 set value {title:"Magenta Bundle", description:"Obtenir un(e) Magenta Bundle", namespace:"bingo_0b", step:"2", line:"4", column:"4"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 4_4
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:4_4
