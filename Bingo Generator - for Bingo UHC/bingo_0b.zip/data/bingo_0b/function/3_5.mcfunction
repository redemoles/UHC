
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 3_5 set value {title:"Comparator", description:"Obtenir un(e) Comparator", namespace:"bingo_0b", step:"2", line:"3", column:"5"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 3_5
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:3_5
