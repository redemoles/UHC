
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 1_4 set value {title:"Stripped Bamboo Block", description:"Obtenir un(e) Stripped Bamboo Block", namespace:"bingo_0b", step:"2", line:"1", column:"4"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 1_4
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:1_4
