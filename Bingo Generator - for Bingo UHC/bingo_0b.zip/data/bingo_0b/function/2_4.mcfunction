
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 2_4 set value {title:"Powder Snow Bucket", description:"Obtenir un(e) Powder Snow Bucket", namespace:"bingo_0b", step:"2", line:"2", column:"4"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 2_4
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:2_4
