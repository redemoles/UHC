
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 1_5 set value {title:"Light Blue Stained Glass Pane", description:"Obtenir un(e) Light Blue Stained Glass Pane", namespace:"bingo_0b", step:"2", line:"1", column:"5"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 1_5
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:1_5
