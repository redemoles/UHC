
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 5_4 set value {title:"Birch Sign", description:"Obtenir un(e) Birch Sign", namespace:"bingo_0b", step:"2", line:"5", column:"4"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 5_4
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:5_4
