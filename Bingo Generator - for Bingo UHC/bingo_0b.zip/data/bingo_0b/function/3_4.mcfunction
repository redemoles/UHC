
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 3_4 set value {title:"Mutton", description:"Obtenir un(e) Mutton", namespace:"bingo_0b", step:"2", line:"3", column:"4"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 3_4
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:3_4
