
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 3_3 set value {title:"Copper Hoe", description:"Obtenir un(e) Copper Hoe", namespace:"bingo_0b", step:"2", line:"3", column:"3"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 3_3
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:3_3
