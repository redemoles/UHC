
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 5_2 set value {title:"Repeater", description:"Obtenir un(e) Repeater", namespace:"bingo_0b", step:"2", line:"5", column:"2"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 5_2
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:5_2
