
execute if score #bingo_0b_enabled bhc.data matches 1 run data modify storage bingo_0b 1_1 set value {title:"Bamboo Trapdoor", description:"Obtenir un(e) Bamboo Trapdoor", namespace:"bingo_0b", step:"2", line:"1", column:"1"}
execute if score #bingo_0b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0b 1_1
execute unless score #bingo_0b_enabled bhc.data matches 1 run advancement revoke @s only bingo_0b:1_1
