
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 7_5 set value {title:"Mossy Stone Bricks", description:"Obtenir un(e) Mossy Stone Bricks", namespace:"bingo_1b", step:"2", line:"7", column:"5"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 7_5
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:7_5
