
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 1_4 set value {title:"Magenta Concrete", description:"Obtenir un(e) Magenta Concrete", namespace:"bingo_1b", step:"2", line:"1", column:"4"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 1_4
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:1_4
