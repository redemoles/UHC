
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 3_1 set value {title:"Mossy Stone Brick Stairs", description:"Obtenir un(e) Mossy Stone Brick Stairs", namespace:"bingo_1b", step:"2", line:"3", column:"1"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 3_1
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:3_1
