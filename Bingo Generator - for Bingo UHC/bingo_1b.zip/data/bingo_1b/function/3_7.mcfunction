
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 3_7 set value {title:"Yellow Bed", description:"Obtenir un(e) Yellow Bed", namespace:"bingo_1b", step:"2", line:"3", column:"7"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 3_7
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:3_7
