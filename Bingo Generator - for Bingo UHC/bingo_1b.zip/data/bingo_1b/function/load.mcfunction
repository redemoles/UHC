
scoreboard players set #line bhc.data 7
scoreboard players set #column bhc.data 7
scoreboard players set #line-1 bhc.data 7
scoreboard players set #column-1 bhc.data 7
scoreboard players remove #line-1 bhc.data 1
scoreboard players remove #column-1 bhc.data 1
scoreboard players set #max bhc.stepb.case 7
scoreboard players operation #max bhc.stepb.case *= #07 uhc.data.numbers
