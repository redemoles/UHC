
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 5_7 set value {title:"Polished Blackstone Brick Wall", description:"Obtenir un(e) Polished Blackstone Brick Wall", namespace:"bingo_1b", step:"2", line:"5", column:"7"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 5_7
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:5_7
