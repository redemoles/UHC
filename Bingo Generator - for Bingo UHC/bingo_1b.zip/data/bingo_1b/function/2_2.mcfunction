
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 2_2 set value {title:"Resin Brick", description:"Obtenir un(e) Resin Brick", namespace:"bingo_1b", step:"2", line:"2", column:"2"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 2_2
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:2_2
