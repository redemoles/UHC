
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 5_1 set value {title:"Birch Fence", description:"Obtenir un(e) Birch Fence", namespace:"bingo_1b", step:"2", line:"5", column:"1"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 5_1
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:5_1
