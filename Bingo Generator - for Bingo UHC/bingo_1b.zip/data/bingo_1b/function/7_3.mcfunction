
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 7_3 set value {title:"Red Sandstone Stairs", description:"Obtenir un(e) Red Sandstone Stairs", namespace:"bingo_1b", step:"2", line:"7", column:"3"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 7_3
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:7_3
