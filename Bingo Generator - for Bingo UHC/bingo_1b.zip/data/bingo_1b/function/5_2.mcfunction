
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 5_2 set value {title:"Chiseled Tuff", description:"Obtenir un(e) Chiseled Tuff", namespace:"bingo_1b", step:"2", line:"5", column:"2"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 5_2
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:5_2
