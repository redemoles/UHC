
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 1_7 set value {title:"Diorite Slab", description:"Obtenir un(e) Diorite Slab", namespace:"bingo_1b", step:"2", line:"1", column:"7"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 1_7
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:1_7
