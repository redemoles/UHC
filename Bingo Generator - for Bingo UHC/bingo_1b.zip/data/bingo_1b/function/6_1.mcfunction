
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 6_1 set value {title:"Lily Of The Valley", description:"Obtenir un(e) Lily Of The Valley", namespace:"bingo_1b", step:"2", line:"6", column:"1"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 6_1
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:6_1
