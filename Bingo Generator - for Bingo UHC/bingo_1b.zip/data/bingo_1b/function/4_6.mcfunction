
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 4_6 set value {title:"Warped Hyphae", description:"Obtenir un(e) Warped Hyphae", namespace:"bingo_1b", step:"2", line:"4", column:"6"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 4_6
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:4_6
