
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 5_3 set value {title:"Pointed Dripstone", description:"Obtenir un(e) Pointed Dripstone", namespace:"bingo_1b", step:"2", line:"5", column:"3"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 5_3
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:5_3
