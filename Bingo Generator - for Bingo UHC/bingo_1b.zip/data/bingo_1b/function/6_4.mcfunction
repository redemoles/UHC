
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 6_4 set value {title:"Blackstone Slab", description:"Obtenir un(e) Blackstone Slab", namespace:"bingo_1b", step:"2", line:"6", column:"4"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 6_4
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:6_4
