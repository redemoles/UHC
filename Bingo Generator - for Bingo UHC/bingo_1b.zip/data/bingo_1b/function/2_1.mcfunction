
execute if score #bingo_1b_enabled bhc.data matches 1 run data modify storage bingo_1b 2_1 set value {title:"Light Gray Glazed Terracotta", description:"Obtenir un(e) Light Gray Glazed Terracotta", namespace:"bingo_1b", step:"2", line:"2", column:"1"}
execute if score #bingo_1b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1b 2_1
execute unless score #bingo_1b_enabled bhc.data matches 1 run advancement revoke @s only bingo_1b:2_1
