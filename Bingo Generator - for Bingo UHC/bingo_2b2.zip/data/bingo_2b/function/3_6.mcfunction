
execute if score #bingo_2b_enabled bhc.data matches 1 run data modify storage bingo_2b 3_6 set value {title:"Tinted Glass", description:"Obtenir un(e) Tinted Glass", namespace:"bingo_2b", step:"2", line:"3", column:"6"}
execute if score #bingo_2b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2b 3_6
execute unless score #bingo_2b_enabled bhc.data matches 1 run advancement revoke @s only bingo_2b:3_6
