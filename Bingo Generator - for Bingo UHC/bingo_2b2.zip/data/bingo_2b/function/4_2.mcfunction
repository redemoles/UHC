
execute if score #bingo_2b_enabled bhc.data matches 1 run data modify storage bingo_2b 4_2 set value {title:"Emerald Block", description:"Obtenir un(e) Emerald Block", namespace:"bingo_2b", step:"2", line:"4", column:"2"}
execute if score #bingo_2b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2b 4_2
execute unless score #bingo_2b_enabled bhc.data matches 1 run advancement revoke @s only bingo_2b:4_2
