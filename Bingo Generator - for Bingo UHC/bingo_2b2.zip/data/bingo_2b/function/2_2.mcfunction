
execute if score #bingo_2b_enabled bhc.data matches 1 run data modify storage bingo_2b 2_2 set value {title:"Deepslate Brick Wall", description:"Obtenir un(e) Deepslate Brick Wall", namespace:"bingo_2b", step:"2", line:"2", column:"2"}
execute if score #bingo_2b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2b 2_2
execute unless score #bingo_2b_enabled bhc.data matches 1 run advancement revoke @s only bingo_2b:2_2
