
execute if score #bingo_2b_enabled bhc.data matches 1 run data modify storage bingo_2b 6_4 set value {title:"Yellow Glazed Terracotta", description:"Obtenir un(e) Yellow Glazed Terracotta", namespace:"bingo_2b", step:"2", line:"6", column:"4"}
execute if score #bingo_2b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2b 6_4
execute unless score #bingo_2b_enabled bhc.data matches 1 run advancement revoke @s only bingo_2b:6_4
