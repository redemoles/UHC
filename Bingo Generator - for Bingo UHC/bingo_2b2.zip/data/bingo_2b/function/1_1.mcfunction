
execute if score #bingo_2b_enabled bhc.data matches 1 run data modify storage bingo_2b 1_1 set value {title:"Smithing Table", description:"Obtenir un(e) Smithing Table", namespace:"bingo_2b", step:"2", line:"1", column:"1"}
execute if score #bingo_2b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2b 1_1
execute unless score #bingo_2b_enabled bhc.data matches 1 run advancement revoke @s only bingo_2b:1_1
