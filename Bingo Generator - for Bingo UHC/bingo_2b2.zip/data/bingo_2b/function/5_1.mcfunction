
execute if score #bingo_2b_enabled bhc.data matches 1 run data modify storage bingo_2b 5_1 set value {title:"Fern", description:"Obtenir un(e) Fern", namespace:"bingo_2b", step:"2", line:"5", column:"1"}
execute if score #bingo_2b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2b 5_1
execute unless score #bingo_2b_enabled bhc.data matches 1 run advancement revoke @s only bingo_2b:5_1
