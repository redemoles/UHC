
execute if score #bingo_2b_enabled bhc.data matches 1 run data modify storage bingo_2b 1_5 set value {title:"Pale Hanging Moss", description:"Obtenir un(e) Pale Hanging Moss", namespace:"bingo_2b", step:"2", line:"1", column:"5"}
execute if score #bingo_2b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2b 1_5
execute unless score #bingo_2b_enabled bhc.data matches 1 run advancement revoke @s only bingo_2b:1_5
