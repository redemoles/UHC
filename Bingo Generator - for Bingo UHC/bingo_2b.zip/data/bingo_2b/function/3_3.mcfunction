
execute if score #bingo_2b_enabled bhc.data matches 1 run data modify storage bingo_2b 3_3 set value {title:"Blackstone Wall", description:"Obtenir un(e) Blackstone Wall", namespace:"bingo_2b", step:"2", line:"3", column:"3"}
execute if score #bingo_2b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2b 3_3
execute unless score #bingo_2b_enabled bhc.data matches 1 run advancement revoke @s only bingo_2b:3_3
