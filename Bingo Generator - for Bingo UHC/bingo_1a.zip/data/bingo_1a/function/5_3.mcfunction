
execute if score #bingo_1a_enabled bhc.data matches 1 run data modify storage bingo_1a 5_3 set value {title:"Brown Bundle", description:"Obtenir un(e) Brown Bundle", namespace:"bingo_1a", step:"1", line:"5", column:"3"}
execute if score #bingo_1a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1a 5_3
execute unless score #bingo_1a_enabled bhc.data matches 1 run advancement revoke @s only bingo_1a:5_3
