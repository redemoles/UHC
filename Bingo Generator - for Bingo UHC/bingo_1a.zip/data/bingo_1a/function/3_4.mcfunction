
execute if score #bingo_1a_enabled bhc.data matches 1 run data modify storage bingo_1a 3_4 set value {title:"Resin Bricks", description:"Obtenir un(e) Resin Bricks", namespace:"bingo_1a", step:"1", line:"3", column:"4"}
execute if score #bingo_1a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1a 3_4
execute unless score #bingo_1a_enabled bhc.data matches 1 run advancement revoke @s only bingo_1a:3_4
