
execute if score #bingo_1a_enabled bhc.data matches 1 run data modify storage bingo_1a 2_5 set value {title:"Magenta Wool", description:"Obtenir un(e) Magenta Wool", namespace:"bingo_1a", step:"1", line:"2", column:"5"}
execute if score #bingo_1a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1a 2_5
execute unless score #bingo_1a_enabled bhc.data matches 1 run advancement revoke @s only bingo_1a:2_5
