
execute if score #bingo_1a_enabled bhc.data matches 1 run data modify storage bingo_1a 1_3 set value {title:"Firework Star", description:"Obtenir un(e) Firework Star", namespace:"bingo_1a", step:"1", line:"1", column:"3"}
execute if score #bingo_1a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1a 1_3
execute unless score #bingo_1a_enabled bhc.data matches 1 run advancement revoke @s only bingo_1a:1_3
