
execute if score #bingo_1a_enabled bhc.data matches 1 run data modify storage bingo_1a 5_4 set value {title:"Cherry Boat", description:"Obtenir un(e) Cherry Boat", namespace:"bingo_1a", step:"1", line:"5", column:"4"}
execute if score #bingo_1a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1a 5_4
execute unless score #bingo_1a_enabled bhc.data matches 1 run advancement revoke @s only bingo_1a:5_4
