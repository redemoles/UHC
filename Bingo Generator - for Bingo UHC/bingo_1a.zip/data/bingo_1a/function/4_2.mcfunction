
execute if score #bingo_1a_enabled bhc.data matches 1 run data modify storage bingo_1a 4_2 set value {title:"Chipped Anvil", description:"Obtenir un(e) Chipped Anvil", namespace:"bingo_1a", step:"1", line:"4", column:"2"}
execute if score #bingo_1a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1a 4_2
execute unless score #bingo_1a_enabled bhc.data matches 1 run advancement revoke @s only bingo_1a:4_2
