
execute if score #bingo_1a_enabled bhc.data matches 1 run data modify storage bingo_1a 5_1 set value {title:"Open Eyeblossom", description:"Obtenir un(e) Open Eyeblossom", namespace:"bingo_1a", step:"1", line:"5", column:"1"}
execute if score #bingo_1a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1a 5_1
execute unless score #bingo_1a_enabled bhc.data matches 1 run advancement revoke @s only bingo_1a:5_1
