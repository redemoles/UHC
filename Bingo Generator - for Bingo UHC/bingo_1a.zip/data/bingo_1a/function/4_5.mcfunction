
execute if score #bingo_1a_enabled bhc.data matches 1 run data modify storage bingo_1a 4_5 set value {title:"Brown Mushroom", description:"Obtenir un(e) Brown Mushroom", namespace:"bingo_1a", step:"1", line:"4", column:"5"}
execute if score #bingo_1a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1a 4_5
execute unless score #bingo_1a_enabled bhc.data matches 1 run advancement revoke @s only bingo_1a:4_5
