
execute if score #bingo_1a_enabled bhc.data matches 1 run data modify storage bingo_1a 3_5 set value {title:"Cornflower", description:"Obtenir un(e) Cornflower", namespace:"bingo_1a", step:"1", line:"3", column:"5"}
execute if score #bingo_1a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1a 3_5
execute unless score #bingo_1a_enabled bhc.data matches 1 run advancement revoke @s only bingo_1a:3_5
