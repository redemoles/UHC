
execute if score #bingo_1a_enabled bhc.data matches 1 run data modify storage bingo_1a 2_2 set value {title:"Dead Bush", description:"Obtenir un(e) Dead Bush", namespace:"bingo_1a", step:"1", line:"2", column:"2"}
execute if score #bingo_1a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_1a 2_2
execute unless score #bingo_1a_enabled bhc.data matches 1 run advancement revoke @s only bingo_1a:2_2
