
execute if score #bingo_91b_enabled bhc.data matches 1 run data modify storage bingo_91b 7_3 set value {title:"Stripped Dark Oak Log", description:"Obtenir un(e) Stripped Dark Oak Log", namespace:"bingo_91b", step:"2", line:"7", column:"3"}
execute if score #bingo_91b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91b 7_3
execute unless score #bingo_91b_enabled bhc.data matches 1 run advancement revoke @s only bingo_91b:7_3
