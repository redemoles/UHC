
execute if score #bingo_91b_enabled bhc.data matches 1 run data modify storage bingo_91b 6_1 set value {title:"Polished Deepslate Slab", description:"Obtenir un(e) Polished Deepslate Slab", namespace:"bingo_91b", step:"2", line:"6", column:"1"}
execute if score #bingo_91b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91b 6_1
execute unless score #bingo_91b_enabled bhc.data matches 1 run advancement revoke @s only bingo_91b:6_1
