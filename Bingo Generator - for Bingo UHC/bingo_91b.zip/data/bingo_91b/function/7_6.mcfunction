
execute if score #bingo_91b_enabled bhc.data matches 1 run data modify storage bingo_91b 7_6 set value {title:"Copper Shovel", description:"Obtenir un(e) Copper Shovel", namespace:"bingo_91b", step:"2", line:"7", column:"6"}
execute if score #bingo_91b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91b 7_6
execute unless score #bingo_91b_enabled bhc.data matches 1 run advancement revoke @s only bingo_91b:7_6
