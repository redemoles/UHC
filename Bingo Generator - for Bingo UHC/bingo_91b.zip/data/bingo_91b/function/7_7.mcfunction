
execute if score #bingo_91b_enabled bhc.data matches 1 run data modify storage bingo_91b 7_7 set value {title:"Nether Brick Stairs", description:"Obtenir un(e) Nether Brick Stairs", namespace:"bingo_91b", step:"2", line:"7", column:"7"}
execute if score #bingo_91b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91b 7_7
execute unless score #bingo_91b_enabled bhc.data matches 1 run advancement revoke @s only bingo_91b:7_7
