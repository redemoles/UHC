
execute if score #bingo_91b_enabled bhc.data matches 1 run data modify storage bingo_91b 4_7 set value {title:"Purple Terracotta", description:"Obtenir un(e) Purple Terracotta", namespace:"bingo_91b", step:"2", line:"4", column:"7"}
execute if score #bingo_91b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91b 4_7
execute unless score #bingo_91b_enabled bhc.data matches 1 run advancement revoke @s only bingo_91b:4_7
