
execute if score #bingo_91b_enabled bhc.data matches 1 run data modify storage bingo_91b 5_4 set value {title:"Glowstone Dust", description:"Obtenir un(e) Glowstone Dust", namespace:"bingo_91b", step:"2", line:"5", column:"4"}
execute if score #bingo_91b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91b 5_4
execute unless score #bingo_91b_enabled bhc.data matches 1 run advancement revoke @s only bingo_91b:5_4
