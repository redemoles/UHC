
execute if score #bingo_91b_enabled bhc.data matches 1 run data modify storage bingo_91b 6_4 set value {title:"Tuff Brick Wall", description:"Obtenir un(e) Tuff Brick Wall", namespace:"bingo_91b", step:"2", line:"6", column:"4"}
execute if score #bingo_91b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91b 6_4
execute unless score #bingo_91b_enabled bhc.data matches 1 run advancement revoke @s only bingo_91b:6_4
