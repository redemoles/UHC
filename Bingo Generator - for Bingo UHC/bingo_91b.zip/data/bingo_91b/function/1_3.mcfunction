
execute if score #bingo_91b_enabled bhc.data matches 1 run data modify storage bingo_91b 1_3 set value {title:"White Stained Glass Pane", description:"Obtenir un(e) White Stained Glass Pane", namespace:"bingo_91b", step:"2", line:"1", column:"3"}
execute if score #bingo_91b_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_91b 1_3
execute unless score #bingo_91b_enabled bhc.data matches 1 run advancement revoke @s only bingo_91b:1_3
