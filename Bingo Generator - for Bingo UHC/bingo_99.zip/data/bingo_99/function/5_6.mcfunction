
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 5_6 set value {title:"Mud Brick Stairs", description:"Obtenir un(e) Mud Brick Stairs", namespace:"bingo_99", step:"1", line:"5", column:"6"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 5_6
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:5_6
