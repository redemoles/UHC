
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 3_4 set value {title:"Pumpkin Pie", description:"Obtenir un(e) Pumpkin Pie", namespace:"bingo_99", step:"1", line:"3", column:"4"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 3_4
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:3_4
