
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 3_2 set value {title:"Magma Cream", description:"Obtenir un(e) Magma Cream", namespace:"bingo_99", step:"1", line:"3", column:"2"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 3_2
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:3_2
