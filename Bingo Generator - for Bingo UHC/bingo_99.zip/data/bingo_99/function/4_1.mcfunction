
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 4_1 set value {title:"Oak Chest Boat", description:"Obtenir un(e) Oak Chest Boat", namespace:"bingo_99", step:"1", line:"4", column:"1"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 4_1
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:4_1
