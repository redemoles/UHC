
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 1_4 set value {title:"Compass", description:"Obtenir un(e) Compass", namespace:"bingo_99", step:"1", line:"1", column:"4"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 1_4
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:1_4
