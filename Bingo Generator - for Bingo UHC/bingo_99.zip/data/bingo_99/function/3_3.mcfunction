
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 3_3 set value {title:"Brewing Stand", description:"Obtenir un(e) Brewing Stand", namespace:"bingo_99", step:"1", line:"3", column:"3"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 3_3
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:3_3
