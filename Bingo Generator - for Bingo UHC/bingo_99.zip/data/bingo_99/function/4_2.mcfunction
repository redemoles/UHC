
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 4_2 set value {title:"Green Banner", description:"Obtenir un(e) Green Banner", namespace:"bingo_99", step:"1", line:"4", column:"2"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 4_2
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:4_2
