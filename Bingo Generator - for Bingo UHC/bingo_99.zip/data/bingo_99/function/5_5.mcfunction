
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 5_5 set value {title:"Copper Shovel", description:"Obtenir un(e) Copper Shovel", namespace:"bingo_99", step:"1", line:"5", column:"5"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 5_5
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:5_5
