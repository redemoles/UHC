
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 2_5 set value {title:"Pale Oak Door", description:"Obtenir un(e) Pale Oak Door", namespace:"bingo_99", step:"1", line:"2", column:"5"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 2_5
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:2_5
