
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 6_4 set value {title:"Chiseled Resin Bricks", description:"Obtenir un(e) Chiseled Resin Bricks", namespace:"bingo_99", step:"1", line:"6", column:"4"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 6_4
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:6_4
