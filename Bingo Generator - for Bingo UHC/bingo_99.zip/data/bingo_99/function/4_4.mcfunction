
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 4_4 set value {title:"Pale Moss Carpet", description:"Obtenir un(e) Pale Moss Carpet", namespace:"bingo_99", step:"1", line:"4", column:"4"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 4_4
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:4_4
