
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 4_3 set value {title:"Golden Shovel", description:"Obtenir un(e) Golden Shovel", namespace:"bingo_99", step:"1", line:"4", column:"3"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 4_3
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:4_3
