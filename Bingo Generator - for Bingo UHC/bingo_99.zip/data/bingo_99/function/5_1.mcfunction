
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 5_1 set value {title:"Target", description:"Obtenir un(e) Target", namespace:"bingo_99", step:"1", line:"5", column:"1"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 5_1
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:5_1
