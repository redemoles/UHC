
execute if score #bingo_99_enabled bhc.data matches 1 run data modify storage bingo_99 2_6 set value {title:"Jungle Sapling", description:"Obtenir un(e) Jungle Sapling", namespace:"bingo_99", step:"1", line:"2", column:"6"}
execute if score #bingo_99_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_99 2_6
execute unless score #bingo_99_enabled bhc.data matches 1 run advancement revoke @s only bingo_99:2_6
