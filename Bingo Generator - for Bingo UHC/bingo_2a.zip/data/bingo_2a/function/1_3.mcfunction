
execute if score #bingo_2a_enabled bhc.data matches 1 run data modify storage bingo_2a 1_3 set value {title:"Yellow Glazed Terracotta", description:"Obtenir un(e) Yellow Glazed Terracotta", namespace:"bingo_2a", step:"1", line:"1", column:"3"}
execute if score #bingo_2a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2a 1_3
execute unless score #bingo_2a_enabled bhc.data matches 1 run advancement revoke @s only bingo_2a:1_3
