
scoreboard players set #line bhc.data 5
scoreboard players set #column bhc.data 5
scoreboard players set #line-1 bhc.data 5
scoreboard players set #column-1 bhc.data 5
scoreboard players remove #line-1 bhc.data 1
scoreboard players remove #column-1 bhc.data 1
scoreboard players set #max bhc.stepa.case 5
scoreboard players operation #max bhc.stepa.case *= #05 uhc.data.numbers
