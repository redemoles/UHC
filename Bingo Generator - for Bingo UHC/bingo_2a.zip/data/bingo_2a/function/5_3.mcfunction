
execute if score #bingo_2a_enabled bhc.data matches 1 run data modify storage bingo_2a 5_3 set value {title:"Warped Wart Block", description:"Obtenir un(e) Warped Wart Block", namespace:"bingo_2a", step:"1", line:"5", column:"3"}
execute if score #bingo_2a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2a 5_3
execute unless score #bingo_2a_enabled bhc.data matches 1 run advancement revoke @s only bingo_2a:5_3
