
execute if score #bingo_2a_enabled bhc.data matches 1 run data modify storage bingo_2a 2_5 set value {title:"Tnt", description:"Obtenir un(e) Tnt", namespace:"bingo_2a", step:"1", line:"2", column:"5"}
execute if score #bingo_2a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2a 2_5
execute unless score #bingo_2a_enabled bhc.data matches 1 run advancement revoke @s only bingo_2a:2_5
