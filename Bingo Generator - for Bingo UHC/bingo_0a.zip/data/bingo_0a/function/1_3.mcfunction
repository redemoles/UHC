
execute if score #bingo_0a_enabled bhc.data matches 1 run data modify storage bingo_0a 1_3 set value {title:"Dark Oak Trapdoor", description:"Obtenir un(e) Dark Oak Trapdoor", namespace:"bingo_0a", step:"1", line:"1", column:"3"}
execute if score #bingo_0a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0a 1_3
execute unless score #bingo_0a_enabled bhc.data matches 1 run advancement revoke @s only bingo_0a:1_3
