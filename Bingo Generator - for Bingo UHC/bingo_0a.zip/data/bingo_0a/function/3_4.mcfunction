
execute if score #bingo_0a_enabled bhc.data matches 1 run data modify storage bingo_0a 3_4 set value {title:"White Carpet", description:"Obtenir un(e) White Carpet", namespace:"bingo_0a", step:"1", line:"3", column:"4"}
execute if score #bingo_0a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0a 3_4
execute unless score #bingo_0a_enabled bhc.data matches 1 run advancement revoke @s only bingo_0a:3_4
