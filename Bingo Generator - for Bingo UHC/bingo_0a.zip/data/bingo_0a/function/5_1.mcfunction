
execute if score #bingo_0a_enabled bhc.data matches 1 run data modify storage bingo_0a 5_1 set value {title:"Stripped Warped Hyphae", description:"Obtenir un(e) Stripped Warped Hyphae", namespace:"bingo_0a", step:"1", line:"5", column:"1"}
execute if score #bingo_0a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0a 5_1
execute unless score #bingo_0a_enabled bhc.data matches 1 run advancement revoke @s only bingo_0a:5_1
