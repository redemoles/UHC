
execute if score #bingo_0a_enabled bhc.data matches 1 run data modify storage bingo_0a 3_5 set value {title:"Packed Mud", description:"Obtenir un(e) Packed Mud", namespace:"bingo_0a", step:"1", line:"3", column:"5"}
execute if score #bingo_0a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0a 3_5
execute unless score #bingo_0a_enabled bhc.data matches 1 run advancement revoke @s only bingo_0a:3_5
