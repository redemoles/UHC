
execute if score #bingo_0a_enabled bhc.data matches 1 run data modify storage bingo_0a 5_3 set value {title:"Orange Banner", description:"Obtenir un(e) Orange Banner", namespace:"bingo_0a", step:"1", line:"5", column:"3"}
execute if score #bingo_0a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0a 5_3
execute unless score #bingo_0a_enabled bhc.data matches 1 run advancement revoke @s only bingo_0a:5_3
