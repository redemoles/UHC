
execute if score #bingo_0a_enabled bhc.data matches 1 run data modify storage bingo_0a 5_2 set value {title:"Dark Oak Fence Gate", description:"Obtenir un(e) Dark Oak Fence Gate", namespace:"bingo_0a", step:"1", line:"5", column:"2"}
execute if score #bingo_0a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0a 5_2
execute unless score #bingo_0a_enabled bhc.data matches 1 run advancement revoke @s only bingo_0a:5_2
