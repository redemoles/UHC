
execute if score #bingo_0a_enabled bhc.data matches 1 run data modify storage bingo_0a 3_3 set value {title:"Oak Sign", description:"Obtenir un(e) Oak Sign", namespace:"bingo_0a", step:"1", line:"3", column:"3"}
execute if score #bingo_0a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_0a 3_3
execute unless score #bingo_0a_enabled bhc.data matches 1 run advancement revoke @s only bingo_0a:3_3
