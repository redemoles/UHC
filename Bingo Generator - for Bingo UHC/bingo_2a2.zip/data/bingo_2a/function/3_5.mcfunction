
execute if score #bingo_2a_enabled bhc.data matches 1 run data modify storage bingo_2a 3_5 set value {title:"Resin Clump", description:"Obtenir un(e) Resin Clump", namespace:"bingo_2a", step:"1", line:"3", column:"5"}
execute if score #bingo_2a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2a 3_5
execute unless score #bingo_2a_enabled bhc.data matches 1 run advancement revoke @s only bingo_2a:3_5
