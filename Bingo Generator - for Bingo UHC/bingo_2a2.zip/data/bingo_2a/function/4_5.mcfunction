
execute if score #bingo_2a_enabled bhc.data matches 1 run data modify storage bingo_2a 4_5 set value {title:"Tuff Brick Wall", description:"Obtenir un(e) Tuff Brick Wall", namespace:"bingo_2a", step:"1", line:"4", column:"5"}
execute if score #bingo_2a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2a 4_5
execute unless score #bingo_2a_enabled bhc.data matches 1 run advancement revoke @s only bingo_2a:4_5
