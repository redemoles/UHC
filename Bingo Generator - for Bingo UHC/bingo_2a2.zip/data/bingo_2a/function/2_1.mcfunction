
execute if score #bingo_2a_enabled bhc.data matches 1 run data modify storage bingo_2a 2_1 set value {title:"Blue Stained Glass", description:"Obtenir un(e) Blue Stained Glass", namespace:"bingo_2a", step:"1", line:"2", column:"1"}
execute if score #bingo_2a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2a 2_1
execute unless score #bingo_2a_enabled bhc.data matches 1 run advancement revoke @s only bingo_2a:2_1
