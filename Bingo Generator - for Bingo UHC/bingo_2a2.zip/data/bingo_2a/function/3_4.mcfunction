
execute if score #bingo_2a_enabled bhc.data matches 1 run data modify storage bingo_2a 3_4 set value {title:"Armor Stand", description:"Obtenir un(e) Armor Stand", namespace:"bingo_2a", step:"1", line:"3", column:"4"}
execute if score #bingo_2a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2a 3_4
execute unless score #bingo_2a_enabled bhc.data matches 1 run advancement revoke @s only bingo_2a:3_4
