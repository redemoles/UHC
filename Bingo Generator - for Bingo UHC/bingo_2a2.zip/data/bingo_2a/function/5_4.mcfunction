
execute if score #bingo_2a_enabled bhc.data matches 1 run data modify storage bingo_2a 5_4 set value {title:"Jungle Chest Boat", description:"Obtenir un(e) Jungle Chest Boat", namespace:"bingo_2a", step:"1", line:"5", column:"4"}
execute if score #bingo_2a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2a 5_4
execute unless score #bingo_2a_enabled bhc.data matches 1 run advancement revoke @s only bingo_2a:5_4
