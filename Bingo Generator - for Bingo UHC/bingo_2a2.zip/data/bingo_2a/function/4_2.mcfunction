
execute if score #bingo_2a_enabled bhc.data matches 1 run data modify storage bingo_2a 4_2 set value {title:"Orange Concrete", description:"Obtenir un(e) Orange Concrete", namespace:"bingo_2a", step:"1", line:"4", column:"2"}
execute if score #bingo_2a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2a 4_2
execute unless score #bingo_2a_enabled bhc.data matches 1 run advancement revoke @s only bingo_2a:4_2
