
execute if score #bingo_2a_enabled bhc.data matches 1 run data modify storage bingo_2a 1_5 set value {title:"Lily Of The Valley", description:"Obtenir un(e) Lily Of The Valley", namespace:"bingo_2a", step:"1", line:"1", column:"5"}
execute if score #bingo_2a_enabled bhc.data matches 1 run function #bhc:advancements with storage bingo_2a 1_5
execute unless score #bingo_2a_enabled bhc.data matches 1 run advancement revoke @s only bingo_2a:1_5
